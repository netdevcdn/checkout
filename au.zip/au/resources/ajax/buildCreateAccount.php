

<div id='kcartSignin'>
	<form id='kformSignup'>
    
    	<input type='text' name='eCommerceLogin2' readonly value = '<?php echo $ksdk->getEmailAddress(); ?>' isRequired>
    	<br>	
    	<input type='password' name='eCommercePassword2' placeholder='Password' isRequired>
    	<br>
        <br>
    	<p> Creating an account let's you place your next order quicker!</p>
    	<input type='submit' style='float:right' value='Create Account'>
        
    	<div style='clear:both'></div>
    </form>
</div>