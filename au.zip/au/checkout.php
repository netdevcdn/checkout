<?php
require_once realpath(dirname(__FILE__)."/resources/konnektiveSDK.php");
$pageType = "checkoutPage"; 
$deviceType = "ALL"; 
$ksdk = new KonnektiveSDK($pageType,$deviceType);
$productId = $ksdk->page->productId;
$offer = $ksdk->getProduct((int) $productId);

//echo $offers;
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!--------------- Meta tags start --------------->
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scalable=0" />
	<meta name="format-detection" content="telephone=no" />
	<meta name=theme-color content="#F24947" />   
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="referrer" content="no-referrer">
	<meta name="robots" content="noindex, nofollow, noarchive">
	<!--------------- Meta tags end --------------->
	<!-- Page title -->
	<title>Checkout</title>
	<!-- Favicon -->
	<link href="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/images/favicon.svg" rel="shortcut icon" type="image/x-icon" />
	<!-- CSS Links -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/Netizenstech/checkout@v.1.1/assets/css/app.css" />
	<style>.action-button {background: #3fb331; border: #3fb331;}.action-button:hover{background: #58ca4a; border: #58ca4a; color: #FFFFFF;}.top_terms{font-size: 7px; text-align: center; color: #FFF; padding-bottom: 25px; padding-left: 30px; padding-right: 30px; padding-top: 5px;}.checkout-header{padding-top: 0px !important;}</style>
        <?php 
//this line of code must go either inside the <head> </head> tags or inside the <body></body> tags
$ksdk->echoJavascript();
?>
</head>

<body class="home-page">
	<!-- MultiStep Form -->
	<main class="main-wrapper">
		<section class="checkout-wrapper">
			<div class="checkout-header">
				<div class="top_terms">
					All new users will participate in a competition for the displayed product. This campaign ends on the 31st December <?php echo date("Y"); ?>. This is a special offer which includes a 3-day trial to one of our affiliate associated websites followed by an ongoing membership charge of $69.00 charged each 30 days.
					</div>
				<div class="container" style="padding-top: 10px;">
					<div class="checkout-header-inner">
						<div class="safe-payment">
							<h6><img src="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/images/encryption.svg" alt="Icon"> SSL safe payment</h6>
						</div>
						<div class="title">
							<h5>Secure Payment</h5>
						</div>
						<div class="verify">
							<h6>Verified by <img src="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/images/visa-icons.svg" alt="Icon"></h6>
						</div>
					</div>
				</div>
			</div>
			<div class="checkout-main">
				<div class="container">
					<div class="ckform">
						<!-- progressbar -->
						<ul id="progressbar">
							<li class="active"  id="account">
								<div class="icon"></div>
								Information
							</li>
							<li class="active" id="personal">
								<div class="icon"></div>
								Payment
							</li>
							<li id="payment">
								<div class="icon"></div>
								Confirmation
							</li>
						</ul>
					</div>
				</div>
				<div class="checkout-content">
					<div class="container">
						<!-- fieldsets -->
						<fieldset>
							<div class="plan-pricing payments">
								<div class="row justify-content-center gx-5">
									<div class="col-md-10 col-lg-6 order-2 order-lg-1">
										<div class="account-form">
											<div class="account-header">
												<div class="title">
													<h2>Payment <img src="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/images/payments.svg" alt="Icon"> </h2>
												</div>
											</div>
											<div class="account-content">
										
                                                 <form method="POST"  id='kform' class='kform form-group' onsubmit='return false;' style="margin-top: 10px;" >
              <input type="hidden" name="browserData" value="" id="browserData">
              <input type="hidden" name='paySource' value="CREDITCARD">
													<div class="form-row">
														<div class="form-group col-12">
															<input type="text" name="cardNumber" id="cardNumber" maxlength="16" isRequired class="user-input"
																placeholder="Carn number" required>
														</div>
													</div>
													<div class="row">
														<div class="form-group col-6">
															<select isRequired id='ccexpmonth' name='cardMonth' class="user-input form-select form-select-sm" aria-label=".form-select-sm example">
																<option selected>Select Month</option>
																<option value='01'>01</option>
																<option value='02'>02</option>
																<option value='03'>03</option>
																<option value='04'>04</option>
																<option value='05'>05</option>
																<option value='06'>06</option>
																<option value='07'>07</option>
																<option value='08'>08</option>
																<option value='09'>09</option>
																<option value='10'>10</option>
																<option value='11'>11</option>
																<option value='12'>12</option>
															</select>
														</div>
														<div class="form-group col-6">
															<select class="user-input form-select form-select-sm" aria-label=".form-select-sm example" name='cardYear' id='cardYear' isRequired>
																<option selected>Select Year</option>
																<option value="2022">2022</option>
																<option value="2023">2023</option>
																<option value="2024">2024</option>
																<option value="2025">2025</option>
																<option value="2026">2026</option>
																<option value="2027">2027</option>
																<option value="2028">2028</option>
																<option value="2029">2029</option>
																<option value="2030">2030</option>
																<option value="2031">2031</option>
																<option value="2032">2032</option>
																<option value="2033">2033</option>
																<option value="2034">2034</option>
																<option value="2035">2035</option>
																<option value="2036">2036</option>
																<option value="2037">2037</option>
																<option value="2038">2038</option>
																<option value="2039">2039</option>
																<option value="2040">2040</option>
																<option value="2041">2041</option>
																<option value="2042">2042</option>
															</select>
														</div>
													</div>
													<div class="row">
														<div class="form-group col-sm-6 col-9">
															<input type="number" isRequired name="cardSecurityCode" id="cardSecurityCode" maxlength="3" class="user-input" placeholder="CVV"
																required="">
														</div>
														<div class="form-group col-sm-6 col-3 align-self-center">
															<img width="50" src="cvv.png" alt="">
														</div>
													</div>
													<button type="submit" id='kformSubmit' class="kform_submitBtn next action-button" style="font-size: 16px;">Pay Now</button>
												</form>
											</div>
										</div>
									</div>
									<div class="col-md-10 col-lg-6 order-1 order-lg-2">
										<div class="order-summary">
											<div class="order-title">
												<h2>Order Summary</h2>
											</div>
											<div class="summary-list">
												<ul>
													<li>
														<h6>Service Price</h6>
														<h6>Free</h6>
													</li>
													<li class="total">
														<h6>Order Total</h6>
														<h6><?php echo $ksdk->currencySymbol.$offer->price; ?></h6>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
						</fieldset>
					</div>
					
				</div>
			</div>
			<div class="col-md-12" style="text-align: center; margin-top: 25px;">
				<img src="pic1.png" width="100px">
				<img src="pic4.png" width="100px">
				<img src="pic5.png" width="100px">
			</div>
			<div class="col-md-12" style="text-align: center; font-size: 12px; margin-top: 25px;">Copyright © <?php echo date("Y"); ?> All rights reserved</div>
		</section>
	</main>

	<script src="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/js/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" ></script>
	<script src="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/js/app.js"></script>
	<script type="text/javascript">
		window.onload = function() {
			var register = document.getElementsByClassName('top_terms')[0];
	
			if (typeof(register) != 'undefined' && register != null) {
					setTimeout(function() {
					window.scroll(0, 0);
				}, 10);
				setTimeout(function() {
					window.scroll(0, document.getElementsByClassName('top_terms')[0].offsetHeight);
				}, 20);
			}
		}
		</script>
    <script>    const navigator = window.navigator;
    const browserData = {
        acceptHeader: 'application/json',
        userAgent: navigator.userAgent,
        language: navigator.language,
        timezone: (new Date()).getTimezoneOffset().toString(),
        colorDepth: screen.colorDepth,
        screen: {
            height: screen.height.toString(),
            width: screen.width.toString()
        },
        javaScriptEnabled: true,
        javaEnabled: navigator.javaEnabled()
    };
    document.getElementById('browserData').value = JSON.stringify(browserData);</script>

</body>
</html>