<?php
require_once realpath(dirname(__FILE__)."/resources/konnektiveSDK.php");
$pageType = "leadPage"; 
$deviceType = "ALL"; 
$ksdk = new KonnektiveSDK($pageType,$deviceType);
$productId = $ksdk->page->productId;
$offer = $ksdk->getProduct((int) $productId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<!--------------- Meta tags start --------------->
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0,user-scalable=0" />
	<meta name="format-detection" content="telephone=no" />
	<meta name=theme-color content="#F24947" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="referrer" content="no-referrer">
	<meta name="robots" content="noindex, nofollow, noarchive">
	<!--------------- Meta tags end --------------->
	<!-- Page title -->
	<title>Checkout</title>
	<!-- Favicon -->
	<link href="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/images/favicon.svg" rel="shortcut icon" type="image/x-icon" />
	<!-- CSS Links -->
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/gh/Netizenstech/checkout@v.1.1/assets/css/app.css" />
	<style>.action-button {background: #3fb331; border: #3fb331;}.action-button:hover{background: #58ca4a; border: #58ca4a; color: #FFFFFF;}.top_terms{font-size: 7px; text-align: center; color: #FFF; padding-bottom: 25px; padding-left: 30px; padding-right: 30px; padding-top: 5px;}.checkout-header{padding-top: 0px !important;}#footer-terms {text-align: center; margin-top: 25px; font-size: 10px !important; padding-left: 30px; padding-right:30px; color: #A4A3A3;}@media only screen and (min-width: 1px) and (max-width: 979px) {}</style>
	<?php $ksdk->echoJavascript(); ?>
    <script>
          var iti = null;
      </script>
</head>

<body class="home-page">
	<!-- MultiStep Form -->
	<main class="main-wrapper">
		<section class="checkout-wrapper">
			<div class="checkout-header">
				<div class="top_terms">
					All new users will participate in a competition for the displayed product. This campaign ends on the 31st December <?php echo date("Y"); ?>. This is a special offer which includes a 3-day trial to one of our affiliate associated websites followed by an ongoing membership charge of $69.00 charged each 30 days.
					</div>
				<div class="container" style="padding-top: 10px;">
					<div class="checkout-header-inner">
						<div class="safe-payment">
							<h6><img src="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/images/encryption.svg" alt="Icon"> SSL safe payment</h6>
						</div>
						<div class="title">
							<h5>Secure Payment</h5>
						</div>
						<div class="verify">
							<h6>Verified by <img src="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/images/visa-icons.svg" alt="Icon"></h6>
						</div>
					</div>
				</div>
			</div>
			<div class="checkout-main">
				<div class="container">
					<div class="ckform">
						<!-- progressbar -->
						<ul id="progressbar">
							<li class="active" id="account">
								<div class="icon"></div>
								Information
							</li>
							<li id="personal">
								<div class="icon"></div>
								Payment
							</li>
							<li id="payment">
								<div class="icon"></div>
								Confirmation
							</li>
						</ul>
					</div>
				</div>
				<div class="checkout-content">
					<div class="container">
						<!-- fieldsets -->
						<fieldset>
							<div class="plan-pricing">
								<div class="row justify-content-center gx-5">
									<div class="col-md-10 col-lg-6 order-2 order-lg-1">
										<div class="account-form ">
											<div class="account-header">
												<div class="title">
													<h2>Information</h2>
												</div>
											</div>
											<div class="account-content">
												<form method="POST" class="form-group" id='kform' onsubmit='return false;'>
													<input type="hidden" name="cartId" value="<?=$cartId?>">                           
													<input type='hidden' name='orderItems' value=''>
                                                    <input type='hidden' name='country' value='AU'>
													<input name='billShipSame' type='hidden' value="1">
                                                    
													<div class="row">
														<div class="form-group col-sm-6">
															<input type="text" name="firstName" id="firstName" class="user-input"
																placeholder="First name" required>
														</div>
														<div class="form-group col-sm-6">
															<input type="text" name="lastName" class="user-input"
																placeholder="Last name" id="lastName" required>
														</div>
													</div>
													<div class="form-row">
														<div class="form-group col-12">
															<input type="text" name="address1" id="address1" class="user-input" placeholder="Adress" required="">
														</div>
													</div>
													<div class="row">
														<div class="col-sm-6">
															<div class="form-group">
																<input type="text" name="postalCode" id="postalCode" class="user-input"
																	placeholder="Zip code" required="">
															</div>
														</div>
														<div class="col-sm-6">
															<div class="form-group">
																<input type="text" name="city" id="city" class="user-input" placeholder="City"
																	required="">
															</div>
														</div>
													</div>
													
													<!--
													<div class="form-group col-12">
														<select class="user-input form-select form-select-sm" aria-label=".form-select-sm example">
															<option selected>Select State</option>
															<option value="1">One</option>
															<option value="2">Two</option>
															<option value="3">Three</option>
														</select>
													</div>
													-->
													<div class="form-row">
														<div class="form-group col-12">
															<div class="form-group col-12">
																<input type="phone" name="phone" id="phone" class="user-input" onKeyPress="return (event.charCode >= 48 && event.charCode <= 57)" placeholder="Phone" value="+61"
																	required="">
                                                                    <input type="hidden" value="" id="phoneNumber" name="phoneNumber">
															</div>
															<input type="email" name="emailAddress" id="email" class="user-input" placeholder="E-mail"
																required="">
														</div>
														
													</div>
													<input type="button" class="next action-button" id='kformSubmit' value="Continue">
												</form>
											</div>
										</div>
									</div>
									<div class="col-md-10 col-lg-6 order-1 order-lg-2">
										<div class="order-summary">
											<div class="order-title">
												<h2>Order Summary</h2>
											</div>
											<div class="summary-list">
												<ul>
													<li>
														<h6>Service Price</h6>
														<h6>Free</h6>
													</li>
													<li class="total">
														<h6>Order Total</h6>
														<h6><?php echo $ksdk->currencySymbol.$offer->price; ?></h6>
													</li>
												</ul>
											</div>
										</div>
									</div>
								</div>
							</div>
							
						</fieldset>
					</div>
				</div>
			</div>
			<div class="col-md-12" style="text-align: center; margin-top: 25px;">
				<img src="../assets/pic1.png" width="100px">
				<img src="../assets/pic4.png" width="100px">
				<img src="../assets/pic5.png" width="100px">
			</div>
			<div class="col-md-12" id="footer-terms" style=""> 		
				All new users will participate in a competition for the displayed product. The winner will be contacted via e-mail or phone. This campaign ends on December 31st. <?php echo date("Y"); ?>. This is a special offer which includes a 3-day trial to of our affiliate associated websites.
				An on-going membership is provided to one of our affiliate associated websites. Your membership is automatically renewed following a trial period of 3-days. After that, every 30 days you will be charged the full membership price of $69.00. Your membership runs automatically until you choose to cancel. No binding period applies.
			</div>
			<div class="col-md-12" style="text-align: center; font-size: 12px; margin-top: 25px;">Copyright © <?php echo date("Y"); ?> All rights reserved</div>
		</section>
	</main>

	<script src="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/js/jquery-3.6.0.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" ></script>
	<script src="https://cdn.jsdelivr.net/gh/netdevcdn/checkout@master/assets/js/app.js"></script>
	<script type="text/javascript">
	window.onload = function() {
		var register = document.getElementsByClassName('top_terms')[0];

		if (typeof(register) != 'undefined' && register != null) {
				setTimeout(function() {
				window.scroll(0, 0);
			}, 10);
			setTimeout(function() {
				window.scroll(0, document.getElementsByClassName('top_terms')[0].offsetHeight);
			}, 20);
		}
	}
	</script>
    
    <script>
$(document).ready(function(){
 var leave = true;
 
     var code='+61';

	$("#phone").keyup(function(){
	phone=$("#phone").val();
	if($("#phone").val()==''){
	$("#phone").val(code+phone);
	$("#phoneNumber").val(code+phone);
	//if(leave){
	//$("#phone").val('+44'+apt);
	// leave = !leave;
	//}
	}else if(phone.length<4){
	$("#phone").val(code);
	$("#phoneNumber").val(code);
	}
	
	});
});

</script>
    

</body>
</html>